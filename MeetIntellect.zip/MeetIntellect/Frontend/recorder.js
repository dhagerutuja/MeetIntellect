let mediaRecorder;
let meetingWindow;
let audioChunks = []; // Moved to global scope to avoid reset

const API_URL = 'http://localhost:3000/transcribe';

document.getElementById('joinBtn').addEventListener('click', async () => {
  const meetUrl = document.getElementById('meetUrl').value.trim();
  if (!meetUrl) return alert('Please enter a meeting link');

  try {
    meetingWindow = window.open(meetUrl, '_blank');
    console.log('Opened meeting window');

    const stream = await navigator.mediaDevices.getUserMedia({ 
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        sampleRate: 16000 // Standard for Whisper
      }
    });

    mediaRecorder = new MediaRecorder(stream, {
      mimeType: 'audio/webm;codecs=opus', // Force audio-only WebM
      audioBitsPerSecond: 128000
    });

    audioChunks = []; // Reset chunks
    
    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) audioChunks.push(e.data);
    };

    mediaRecorder.onstop = async () => {
      const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
      try {
        document.getElementById('transcript').textContent = 'Processing...';
        const transcript = await transcribeAudio(audioBlob);
        document.getElementById('transcript').textContent = transcript;
      } catch (error) {
        console.error('Transcription failed:', error);
        document.getElementById('transcript').textContent = `Error: ${error.message}`;
      }
    };

    mediaRecorder.start(1000); // Capture every second
    toggleUI(true);

  } catch (error) {
    console.error('Recording setup failed:', error);
    alert(`Error: ${error.message}`);
    if (meetingWindow) meetingWindow.close();
  }
});

async function transcribeAudio(audioBlob) {
  const formData = new FormData();
  formData.append('audio', audioBlob, 'recording.webm'); // Explicit .webm extension

  const response = await fetch(API_URL, {
    method: 'POST',
    body: formData
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(error || 'Server error');
  }
  return await response.text();
}

document.getElementById('leaveBtn').addEventListener('click', () => {
  if (mediaRecorder?.state === 'recording') {
    mediaRecorder.stop();
    mediaRecorder.stream.getTracks().forEach(track => track.stop());
  }
  if (meetingWindow) meetingWindow.close();
  toggleUI(false);
});

function toggleUI(isRecording) {
  document.getElementById('recIndicator').style.display = isRecording ? 'block' : 'none';
  document.getElementById('leaveBtn').disabled = !isRecording;
  document.getElementById('joinBtn').disabled = isRecording;
}